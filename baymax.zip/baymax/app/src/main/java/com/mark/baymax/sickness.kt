package com.mark.baymax

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton

class sickness : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sickness)

        val yellow = findViewById<ImageButton>(R.id.emojiyellow)
        yellow.setOnClickListener {
            val intent = Intent(this, yellow_emoji::class.java)
            startActivity(intent)
        }

        val yellow1 = findViewById<ImageButton>(R.id.emojiyellow2)
        yellow1.setOnClickListener {
            val intent = Intent(this, yellow_emoji::class.java)
            startActivity(intent)
        }

        val yellow2 = findViewById<ImageButton>(R.id.emojiyellow3)
        yellow2.setOnClickListener {
            val intent = Intent(this, yellow_emoji::class.java)
            startActivity(intent)
        }

        val yellow3 = findViewById<ImageButton>(R.id.emojiyellow4)
        yellow3.setOnClickListener {
            val intent = Intent(this, yellow_emoji::class.java)
            startActivity(intent)
        }

        val yellow4 = findViewById<ImageButton>(R.id.emojiyellow5)
        yellow4.setOnClickListener {
            val intent = Intent(this, yellow_emoji::class.java)
            startActivity(intent)
        }

        val orange = findViewById<ImageButton>(R.id.emojiorange)
        orange.setOnClickListener {
            val intent = Intent(this, orange_emoji::class.java)
            startActivity(intent)
        }

        val orange2 = findViewById<ImageButton>(R.id.emojiorange2)
        orange2.setOnClickListener {
            val intent = Intent(this, orange_emoji::class.java)
            startActivity(intent)
        }

        val orange3 = findViewById<ImageButton>(R.id.emojiorange3)
        orange3.setOnClickListener {
            val intent = Intent(this, orange_emoji::class.java)
            startActivity(intent)
        }

        val red = findViewById<ImageButton>(R.id.emojired)
        red.setOnClickListener {
            val intent = Intent(this, red_emoji::class.java)
            startActivity(intent)
        }

        val redtwo = findViewById<ImageButton>(R.id.emojired2)
        redtwo.setOnClickListener {
            val intent = Intent(this, red_emoji::class.java)
            startActivity(intent)
        }
    }
}