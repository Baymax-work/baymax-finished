package com.mark.baymax

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageButton

class injury : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_injury)

        val yellowinjury = findViewById<ImageButton>(R.id.emojiyellow)
        yellowinjury.setOnClickListener {
            val intent = Intent(this, yellow_emoji::class.java)
            startActivity(intent)
        }

        val yellow1 = findViewById<ImageButton>(R.id.emojiyellow2)
        yellow1.setOnClickListener {
            val intent = Intent(this, yellow_emoji::class.java)
            startActivity(intent)
        }

        val yellow2 = findViewById<ImageButton>(R.id.emojiyellow3)
        yellow2.setOnClickListener {
            val intent = Intent(this, yellow_emoji::class.java)
            startActivity(intent)
        }

        val yellow3 = findViewById<ImageButton>(R.id.emojiyellow4)
        yellow3.setOnClickListener {
            val intent = Intent(this, yellow_emoji::class.java)
            startActivity(intent)
        }

        val yellow4 = findViewById<ImageButton>(R.id.emojiyellow5)
        yellow4.setOnClickListener {
            val intent = Intent(this, yellow_emoji::class.java)
            startActivity(intent)
        }

            val orange1 = findViewById<ImageButton>(R.id.emojiorange)
            orange1.setOnClickListener {
                val intent = Intent(this, orange_emoji::class.java)
                startActivity(intent)
            }

            val orange2 = findViewById<ImageButton>(R.id.emojiorange2)
            orange2.setOnClickListener {
                val intent = Intent(this, orange_emoji::class.java)
                startActivity(intent)
            }

            val orange3 = findViewById<ImageButton>(R.id.emojiorange3)
            orange3.setOnClickListener {
                val intent = Intent(this, orange_emoji::class.java)
                startActivity(intent)

            }

            val redone = findViewById<ImageButton>(R.id.emojired)
        redone.setOnClickListener {
            val intent = Intent(this, red_emoji::class.java)
            startActivity(intent)
        }

        val redtwo = findViewById<ImageButton>(R.id.emojired2)
        redtwo.setOnClickListener {
            val intent = Intent(this, red_emoji::class.java)
            startActivity(intent)
        }
    }
}